#Google Causal Impact in R by estimating how much value Volkswagen lost due to its emission scandal.
### Link to the Volkswagen scandal https://www.bbc.com/news/business-34324772
#Google Causal Impact is a fantastic technique for causal inference.
#It uses a difference-in-differences approach to times series data,allowing us to estimate impact over time.
# we go back to 2016, when the CO2 emission scandal happened. 
#At the time, it was discovered that Volkswagen was misleading consumers with understated pollution levels of its cars.
#Such a scandal is bound to hit their market cap. But how much? That is what we will find!


#start date  definition
start = "2014-01-01"
treatment = "2015-09-01"
end = "2015-12-31"

#define a pre and post period
pre.period = as.Date(c(start, treatment))
post.period = as.Date(c(treatment, end))

#retrieve data
install.packages("tseries")
library(tseries)
Volkswagen = get.hist.quote(instrument = "VOW.DE",
                            start = start,
                            end = end,
                            quote = "Close",
                            compression = "w")
Facebook = get.hist.quote(instrument = "META",
                            start = start,
                            end = end,
                            quote = "Close",
                            compression = "w")
Disney = get.hist.quote(instrument = "DIS",
                            start = start,
                            end = end,
                            quote = "Close",
                            compression = "w")
Novartis = get.hist.quote(instrument = "NVS",
                            start = start,
                            end = end,
                            quote = "Close",
                            compression = "w")
Carlsberg = get.hist.quote(instrument = "CARL-B.CO",
                          start = start,
                          end = end,
                          quote = "Close",
                          compression = "w")


#Getting our stocks together
stocks <- cbind(Volkswagen,Facebook,Disney,Carlsberg,Novartis)

#Checking correlations in the training period.The higher the better.
correlation <- window(stocks, start = start, end = treatment)
cor(correlation)


#Getting our stocks together
final_stocks <- cbind(Volkswagen,Disney,Carlsberg,Novartis)


#Doing Causal Impact
install.packages("CausalImpact")
library(CausalImpact)

impact <- CausalImpact(data = final_stocks,
                       pre.period = pre.period,
                       post.period = post.period)

#Checking the results
summary(impact)
plot(impact)


#impact has been a constant straight line there has been no recovery whatsoever.
#This is the result we expected.
#Stock price/ relative KPI Volkswagen lost 30% of its value over the course of 4 months.