#Chi-square Automatic Interaction Detector (CHAID) was a technique created by Gordon V. Kass in 1980.
#CHAID is a tool used to discover the relationship between variables.
#CHAID analysis builds a predictive model, or tree,
##to help determine how variables best merge to explain the outcome in the given dependent variable.

####PROBLEM STATEMENT
#I use a data-driven approach, 
##CHAID, that highlights that the way police treat people of different races is not equal.

#In 2017, all vehicles and drivers that were stopped by the Minneapolis police were documented.
#Characteristics such as Gender, Race, or the part of the town the occurrence happened were recorded.
#We also know whether the vehicle or person was searched, or if the driver was issued a ticket.
#Using CHAID, I try to find the characteristics of the driver that are more likely to lead to their vehicles being searched.

#Install packages and pull data
install.packages("carData")
library(carData)
dataset <- MplsStops
summary(dataset)
str(dataset)

#create final dataset
install.packages("dplyr")
library(dplyr)
dataset <- dataset %>% select(vehicleSearch,
                              race,
                              gender,
                              policePrecinct)
View(dataset)
#transform numerical into factors
dataset$policePrecinct <- as.factor(dataset$policePrecinct)

#latest R version
install.packages("installr")
library(installr)
updateR()

#Applying CHAID
#install.packages("partykit","grid","libcoin","mvtnorm")
install.packages("CHAID", repos = "https://R-Forge.R-project.org")
library(CHAID)
control <- chaid_control(minbucket = 1000, maxheight = 2)
model <- chaid(vehicleSearch ~ .,
               data = dataset,
               control = control)

#Plotting CHAID output
plot(model,
     gp = gpar(col = "blue",
               fontsize = 7))

#conclusions of the analysis:
#1. Race is the most critical factor that determines whether someone has their vehicle searched.
#2. The black community is the one whose vehicles are searched the most by the Minneapolis police
#3. The Native American community is a close second when it comes to having their vehicles searched.
