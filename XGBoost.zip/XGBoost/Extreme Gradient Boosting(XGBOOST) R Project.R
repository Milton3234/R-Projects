##XGBoost is a state of art Machine Learning algorithm. 
#It is well known for being faster to compute and its results
#more accurate than other well-known techniques like Neural Networks or Random Forest. 
#XGBoost is also one of the most preferred algorithms in Data Science.
#I use XGBoost to find out the characteristics that correlate best with Remote Work.
#With the help of the SHAP values, which bring explanatory power to Machine Learning,
#I determine the top drivers by importance.



#Loading dataset
install.packages("modeldata")
library(modeldata)
data("stackoverflow")

#isolate x and Y
#install.packages("dplyr")
#library(dplyr)
y <- as.numeric(stackoverflow$Remote) -1
x <- stackoverflow %>% select(-Remote)
str(x)


#transform factor into dummy variable
install.packages("fastDummies")
library(fastDummies)
x <- dummy_cols(x,
                remove_first_dummy = TRUE)
x <- x %>% select(-Country)

#setting parameters
params <- list(set.seed = 1502,
               eval_metric = "auc",
               objective = "binary:logistic")

#running xgboost
install.packages("xgboost")
library(xgboost)
model <- xgboost(data = as.matrix(x),
                 label = y,
                 params = params,
                 nrounds = 20,
                 verbose = 1)

#shap values
xgb.plot.shap(data = as.matrix(x),
              model = model,
              top_n = 5)


#Here are some of the conclusions of the analysis:
#1) Remote workers earn on average less.
#2) Remote workers show lower career satisfaction.
#3) Medium-size companies, between 500 and 10k employees, are less likely to hire remote workers.

