#APRIORI ALGORITHM
##is an algorithm for frequent item set mining and association rule learning over relational databases.
##It proceeds by identifying the frequent individual items in the database and extending them to larger
##and larger item sets as long as those item sets appear sufficiently often in the database.


#get the data
install.packages("arules")
library(arules)
data("Groceries")
head(as(Groceries, "list"),5)


#apriori
model = apriori(data = Groceries,
                parameter = list(support = 0.001,
                                 confidence = 0.15))

##  Visualization
inspect(sort(model, by = 'lift')[1:10])


#The Apriori algorithm is widely used in market basket analysis, 
#where the goal is to identify associations between items that are frequently purchased together.
#It is also used in other applications such as bioinformatics, web usage mining, and fraud detection.
